package id.pranaja.antivirus;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
